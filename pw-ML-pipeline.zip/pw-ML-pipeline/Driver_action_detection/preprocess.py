def download_from_s3(s3_uri, local_path):
    """Download data from S3 bucket to local path"""
    bucket, prefix = parse_s3_uri(s3_uri)
    s3_client = boto3.client('s3')
    # print("s3client:",s3_client)
    
    try:
        os.makedirs(local_path, exist_ok=True)
        print(os.makedirs(local_path, exist_ok=True))
        
        paginator = s3_client.get_paginator('list_objects_v2')
        for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
            if 'Contents' not in page:
                continue
                
            for obj in page['Contents']:
                relative_path = obj['Key'][len(prefix):].lstrip('/')
                if not relative_path:
                    continue
                    
                local_file_path = os.path.join(local_path, relative_path)
                os.makedirs(os.path.dirname(local_file_path), exist_ok=True)
                
                s3_client.download_file(bucket, obj['Key'], local_file_path)
                logger.info(f"Downloaded {obj['Key']} to {local_file_path}")
                
    except ClientError as e:
        logger.error(f"Error downloading from S3: {str(e)}")
        raise