# ecr_setup.py
import boto3
import subprocess
import os
import base64

def create_ecr_repository(repository_name):
    """Create ECR repository if it doesn't exist"""
    ecr_client = boto3.client('ecr')
    try:
        ecr_client.create_repository(repositoryName=repository_name)
        print(f"Created repository: {repository_name}")
    except ecr_client.exceptions.RepositoryAlreadyExistsException:
        print(f"Repository already exists: {repository_name}")

def build_and_push_container(repository_name, dockerfile_path, tag="latest"):     #2
    """Build and push Docker container to ECR"""
    ecr_client = boto3.client('ecr')
    account_id = boto3.client('sts').get_caller_identity()['Account']
    region = boto3.session.Session().region_name
    
    # Get ECR login token
    token = ecr_client.get_authorization_token()
    #print(token)
    username, password = (
        #boto3.utils.base64.b64decode(token['authorizationData'][0]['authorizationToken'])
        base64.b64decode(token['authorizationData'][0]['authorizationToken'])
        .decode('utf-8')
        .split(':')
    )
    registry_url = f"{account_id}.dkr.ecr.{region}.amazonaws.com"
    print("registry_url: ", registry_url)

    # Login to ECR
    login_command = f"docker login -u {username} -p {password} {registry_url}"
    subprocess.run(login_command, shell=True, check=True)
    
    # Build Docker image
    image_uri = f"{registry_url}/{repository_name}:{tag}"
    build_command = f"docker build -t {repository_name} -f {dockerfile_path} ."
    subprocess.run(build_command, shell=True, check=True, cwd=os.path.dirname(dockerfile_path))
    
    # Tag image
    tag_command = f"docker tag {repository_name}:{tag} {image_uri}"
    subprocess.run(tag_command, shell=True, check=True)
    
    # Push to ECR
    push_command = f"docker push {image_uri}"
    subprocess.run(push_command, shell=True, check=True)
    
    return "image_uri"

def main():
    # Create repositories
    repositories = [
        "driver-actions-preprocessing",
        "yolov8-training"
    ]
    
    for repo in repositories:
        create_ecr_repository(repo)
    
    # Build and push preprocessing container
    preprocessing_image = build_and_push_container(   #1
        "driver-actions-preprocessing",
        "docker/preprocessing/Dockerfile"
    )
    print(f"Preprocessing container URI: {preprocessing_image}")
    
    # Build and push training container
    training_image = build_and_push_container(
        "yolov8-training",
        "docker/training/Dockerfile"
    )
    print(f"Training container URI: {training_image}")

if __name__ == "__main__":
    main()