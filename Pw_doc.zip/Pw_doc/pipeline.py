import os
import logging
import boto3
import yaml
import sagemaker
from datetime import datetime
from pathlib import Path
from sagemaker.pytorch import PyTorch
from sagemaker.workflow.pipeline import Pipeline
from sagemaker.workflow.steps import (
    ProcessingStep, 
    TrainingStep,
    TuningStep,
    CacheConfig
)
from sagemaker.workflow.model_step import ModelStep
from sagemaker.workflow.pipeline_context import PipelineSession
from sagemaker.workflow.pipeline_definition_config import PipelineDefinitionConfig
from sagemaker.workflow.functions import Join
from sagemaker.processing import ScriptProcessor, ProcessingInput, ProcessingOutput
from sagemaker.inputs import TrainingInput
from sagemaker.model_metrics import MetricsSource, ModelMetrics
from sagemaker.workflow.parameters import (
    ParameterInteger,
    ParameterString,
    ParameterFloat
)
from sagemaker.workflow.properties import PropertyFile
from sagemaker.workflow.conditions import ConditionGreaterThanOrEqualTo
from sagemaker.workflow.condition_step import ConditionStep
from sagemaker.workflow.retry import RetryPolicy
from sagemaker.model import Model
from sagemaker.workflow.step_collections import RegisterModel

# Set up project directories
PROJECT_ROOT = Path(__file__).parent
PROJECT_NAME = "pw-driver-action-detection"
BASE_DIR = Path.home() / PROJECT_NAME
ML_PIPELINE_DIR = os.path.join(BASE_DIR, 'ml-sagemaker-pipeline')

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
config_path = os.path.join(ML_PIPELINE_DIR, 'config', 'aws_config.yaml')

class YOLOv8Pipeline:
    def __init__(self, config_path=config_path):
        # Load AWS configuration
        self.config = self._load_config(config_path)
        
        # Set AWS configurations
        self.role = self.config['aws']['role_arn']
        self.region = self.config['aws']['region']
        self.bucket = self.config['aws']['bucket']
        self.timestamp = datetime.now().strftime("%Y-%m-%d-%H-%M-%S")
        
        # Set training configurations
        self.instance_type = self.config['training']['instance_type']
        self.instance_count = self.config['training']['instance_count']
        self.framework_version = self.config['training']['framework_version']
        self.py_version = self.config['training']['py_version']
        
        # Initialize sessions
        self.boto_session = boto3.Session(region_name=self.region)
        self.sagemaker_session = sagemaker.Session(
            boto_session=self.boto_session,
            default_bucket=self.bucket
        )
        self.pipeline_session = PipelineSession(
            boto_session=self.boto_session,
            sagemaker_client=self.sagemaker_session.sagemaker_client
        )

        # Set default retry policy
        self.step_retry = RetryPolicy(
            backoff_rate=1.5,
            interval_seconds=60,
            max_attempts=3
        )

        # Cache configuration
        self.cache_config = CacheConfig(
            enable_caching=True,
            expire_after="P1D"
        )

    def _load_config(self, config_path):
        """Load configuration from YAML file"""
        try:
            with open(config_path, 'r') as f:
                config = yaml.safe_load(f)
            logger.info(f"Loaded configuration from: {config_path}")
            return config
        except Exception as e:
            logger.error(f"Error loading config: {str(e)}")
            raise

    def get_pipeline_parameters(self):
        """Define pipeline parameters"""
        return {
            'input_prefix': ParameterString(
                name="InputPrefix",
                default_value=self.config['s3']['input_prefix']
            ),
            'output_prefix': ParameterString(
                name="OutputPrefix",
                default_value=self.config['s3']['output_prefix']
            ),
            'model_prefix': ParameterString(
                name="ModelPrefix",
                default_value=self.config['s3']['model_prefix']
            ),
            'image_size': ParameterInteger(
                name="ImageSize",
                default_value=640
            ),
            'num_classes': ParameterInteger(
                name="NumClasses",
                default_value=12
            ),
            'epochs': ParameterInteger(
                name="Epochs",
                default_value=100
            ),
            'batch_size': ParameterInteger(
                name="BatchSize",
                default_value=16
            ),
            'learning_rate': ParameterFloat(
                name="LearningRate",
                default_value=0.001
            ),
            'patience': ParameterInteger(
                name="Patience",
                default_value=50
            ),
            'map_threshold': ParameterFloat(
                name="MAPThreshold",
                default_value=0.5
            ),
            'optimized_prefix': ParameterString(
                name="OptimizedPrefix",
                default_value=f"{self.config['s3']['model_prefix']}/optimized"
            ),
            'target_instance': ParameterString(
                name="TargetInstance",
                default_value="ml_g4dn"
            )
        }

    def create_preprocessing_step(self, parameters):
        """Create preprocessing step"""
        # Get paths
        preprocessing_dir = os.path.join(ML_PIPELINE_DIR, "preprocessing")
        config_dir = os.path.join(ML_PIPELINE_DIR, "config")
        
        processor = ScriptProcessor(
            image_uri=f"763104351884.dkr.ecr.{self.region}.amazonaws.com/pytorch-training:{self.framework_version}-gpu-{self.py_version}",
            role=self.role,
            instance_count=self.instance_count,
            instance_type=self.instance_type,
            base_job_name=f"driver-action-preprocess-{self.timestamp}",
            command=["python3"],
            sagemaker_session=self.sagemaker_session,
            volume_size_in_gb=100,
            max_runtime_in_seconds=86400
        )

        # Clean and construct S3 URIs
        input_uri = f"s3://{self.bucket}/{self.config['s3']['input_prefix'].rstrip('/')}"
        output_uri = f"s3://{self.bucket}/{self.config['s3']['output_prefix'].rstrip('/')}"

        return ProcessingStep(
            name="PreprocessCVATData",
            processor=processor,
            inputs=[
                ProcessingInput(
                    source=f"{input_uri}/images",
                    destination="/opt/ml/processing/input/images",
                    s3_data_type="S3Prefix"
                ),
                ProcessingInput(
                    source=f"{input_uri}/labels",
                    destination="/opt/ml/processing/input/labels",
                    s3_data_type="S3Prefix"
                ),
                ProcessingInput(
                    source=os.path.join(config_dir, "config.yaml"),
                    destination="/opt/ml/processing/input/config/config.yaml",
                    s3_data_type="S3Prefix"
                )
            ],
            outputs=[
                ProcessingOutput(
                    output_name="training_data",
                    source="/opt/ml/processing/output",
                    destination=output_uri
                )
            ],
            code=preprocessing_dir,
            cache_config=self.cache_config
        )
    
    def create_training_step(self, parameters, preprocessing_step):
        """Create model training step"""
        metrics_definitions = [
            {'Name': 'map', 'Regex': 'metrics/mAP50-95\\(B\\):(.*?);'},
            {'Name': 'map50', 'Regex': 'metrics/mAP50\\(B\\):(.*?);'},
            {'Name': 'precision', 'Regex': 'metrics/precision\\(B\\):(.*?);'},
            {'Name': 'recall', 'Regex': 'metrics/recall\\(B\\):(.*?);'}
        ]
        
        training_data_uri = preprocessing_step.properties.ProcessingOutputConfig.Outputs["training_data"].S3Output.S3Uri
        
        # Clean S3 paths
        model_prefix = self.config['s3']['model_prefix'].strip('/')
        model_output_path = f"s3://{self.bucket}/{model_prefix}"

        estimator = PyTorch(
            entry_point="training_script.py",
            source_dir="training",
            role=self.role,
            framework_version=self.framework_version,
            py_version=self.py_version,
            instance_count=self.instance_count,
            instance_type=self.instance_type,
            volume_size=100,
            max_run=432000,
            metric_definitions=metrics_definitions,
            hyperparameters={
                "epochs": parameters['epochs'],
                "batch-size": parameters['batch_size'],
                "learning-rate": parameters['learning_rate'],
                "image-size": parameters['image_size'],
                "num-classes": parameters['num_classes'],
                "patience": parameters['patience']
            },
            output_path=model_output_path,
            sagemaker_session=self.sagemaker_session
        )

        return TrainingStep(
            name="TrainYOLOv8Model",
            estimator=estimator,
            inputs={
                "training": TrainingInput(
                    s3_data=preprocessing_step.properties.ProcessingOutputConfig.Outputs[
                        "training_data"
                    ].S3Output.S3Uri
                )
            },
            cache_config=self.cache_config
        )

    def create_optimization_step(self, training_step, parameters):
        """Create Neo optimization step"""
        processor = ScriptProcessor(
            image_uri=f"763104351884.dkr.ecr.{self.region}.amazonaws.com/pytorch-training:{self.framework_version}-gpu-{self.py_version}",
            role=self.role,
            instance_count=1,
            instance_type=self.instance_type,
            base_job_name=f"driver-action-optimize-{self.timestamp}",
            command=["python3"],
            sagemaker_session=self.sagemaker_session
        )
    
        return ProcessingStep(
            name="OptimizeModel",
            processor=processor,
            inputs=[
                ProcessingInput(
                    source=training_step.properties.ModelArtifacts.S3ModelArtifacts,
                    destination="/opt/ml/processing/model"
                )
            ],
            outputs=[
                ProcessingOutput(
                    output_name="optimized_model",
                    source="/opt/ml/processing/output",
                    destination=Join(
                        on="/",
                        values=[
                            "s3:/",
                            self.bucket,
                            parameters['model_prefix'],
                            "optimized"
                        ]
                    )
                )
            ],
            code="optimization/neo_opt_script.py",
            job_arguments=[
                "--model-dir", "/opt/ml/processing/model",
                "--output-dir", "/opt/ml/processing/output",
                "--target-instance", "ml_g4dn"
            ],
            cache_config=self.cache_config
        )
    
    def create_evaluation_step(self, training_step, parameters):
        """Create model evaluation step"""
        processor = ScriptProcessor(
            image_uri=f"763104351884.dkr.ecr.{self.region}.amazonaws.com/pytorch-training:{self.framework_version}-gpu-{self.py_version}",
            role=self.role,
            instance_count=self.instance_count,
            instance_type=self.instance_type,
            base_job_name=f"driver-action-evaluate-{self.timestamp}",
            command=["python3"],
            sagemaker_session=self.sagemaker_session
        )

        evaluation_report = PropertyFile(
            name="EvaluationReport",
            output_name="evaluation",
            path="evaluation.json"
        )

        return ProcessingStep(
            name="EvaluateModel",
            processor=processor,
            inputs=[
                ProcessingInput(
                    source=training_step.properties.ModelArtifacts.S3ModelArtifacts,
                    destination="/opt/ml/processing/model"
                ),
                ProcessingInput(
                    source=Join(
                        on="/",
                        values=[
                            "s3:/",
                            self.bucket,
                            parameters['input_prefix'],
                            "images",
                            "test"
                        ]
                    ),
                    destination="/opt/ml/processing/test/images"
                ),
                ProcessingInput(
                    source=Join(
                        on="/",
                        values=[
                            "s3:/",
                            self.bucket,
                            parameters['input_prefix'],
                            "labels"
                        ]
                    ),
                    destination="/opt/ml/processing/test/labels"
                )
            ],
            outputs=[
                ProcessingOutput(
                    output_name="evaluation",
                    source="/opt/ml/processing/evaluation",
                    destination=Join(
                        on="/",
                        values=[
                            "s3:/",
                            self.bucket,
                            parameters['model_prefix'],
                            "evaluation"
                        ]
                    )
                )
            ],
            code="evaluation/evaluate_script.py",
            property_files=[evaluation_report],
            cache_config=self.cache_config
        )

    def create_register_model_step(self, training_step, evaluation_step):
        """Create model registration step"""
        return RegisterModel(
            name="RegisterModel",
            estimator=training_step.estimator,
            model_data=training_step.properties.ModelArtifacts.S3ModelArtifacts,
            content_types=["application/x-image"],
            response_types=["application/json"],
            inference_instances=["ml.g4dn.xlarge"],
            transform_instances=["ml.g4dn.xlarge"],
            model_package_group_name="YOLOv8DriverAction",
            approval_status="PendingManualApproval",
            model_metrics=ModelMetrics(
                model_statistics=MetricsSource(
                    s3_uri=Join(
                        on="/",
                        values=[
                            evaluation_step.properties.ProcessingOutputConfig.Outputs[
                                "evaluation"
                            ].S3Output.S3Uri,
                            "evaluation.json"
                        ]
                    ),
                    content_type="application/json"
                )
            )
        )

    def create_pipeline(self):
        """Create the complete pipeline"""
        parameters = self.get_pipeline_parameters()
        
        preprocessing_step = self.create_preprocessing_step(parameters)
        training_step = self.create_training_step(parameters, preprocessing_step)
        optimization_step = self.create_optimization_step(training_step, parameters)
        evaluation_step = self.create_evaluation_step(training_step, parameters)

        condition = ConditionStep(
            name="CheckMAPThreshold",
            conditions=[ConditionGre